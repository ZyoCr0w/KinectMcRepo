local l = (context.bl and 1) or -1
local item = context.item
local player = context.player
local matrices = context.matrices
local particles = context.particles
global.fall_l = 0.0; 
global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

local physicsItems = {
    "minecraft:bordure_indented_banner_pattern",
    "minecraft:creeper_banner_pattern",
    "minecraft:piglin_banner_pattern",
    "minecraft:flower_banner_pattern",
    "minecraft:field_masoned_banner_pattern",
    "minecraft:skull_banner_pattern",
    "minecraft:mojang_banner_pattern",
    "minecraft:guster_banner_pattern",
    "minecraft:globe_banner_pattern",
    "minecraft:flow_banner_pattern"
}

for _, physicsItem in ipairs(physicsItems) do
    if I:isOf(context.item, Items:get(physicsItem)) 
then
    M:moveY(context.matrices, -0.75)
    M:moveX(context.matrices, 0.1*l)
    M:moveZ(context.matrices, -0.2)
    M:rotateZ(context.matrices, 90*l)
    M:rotateX(context.matrices, -20)
    M:rotateY(context.matrices, -10*l)
    end
end

local physicsItems = {
    "minecraft:waxed_copper_lantern",
    "minecraft:copper_lantern",
    "minecraft:lantern",
    "minecraft:soul_lantern",
    "minecraft:exposed_copper_lantern",
    "minecraft:weathered_copper_lantern",
    "minecraft:oxidized_copper_lantern",
    "minecraft:waxed_exposed_copper_lantern",
    "minecraft:waxed_weathered_copper_lantern",
    "minecraft:waxed_oxidized_copper_lantern"
}

for _, physicsItem in ipairs(physicsItems) do
    if I:isOf(context.item, Items:get(physicsItem)) 
then
    M:moveY(context.matrices, -0.65)
    M:moveX(context.matrices, 0.1*l)
    M:moveZ(context.matrices, -0.2)
    M:rotateZ(context.matrices, 90*l)
    M:rotateX(context.matrices, -20)
    M:rotateY(context.matrices, 0*l)
    end
end

if (
    I:isOf(context.item, Items:get("minecraft:fishing_rod")) or
    I:isOf(context.item, Items:get("minecraft:carrot_on_a_stick")) or
    I:isOf(context.item, Items:get("minecraft:warped_fungus_on_a_stick"))


)
    
then
    M:moveZ(matrices, 0.1 *)
    M:moveY(matrices, -0)
    M:moveX(matrices, -0.01 * l)
    M:rotateZ(matrices, -0.2 *)
end